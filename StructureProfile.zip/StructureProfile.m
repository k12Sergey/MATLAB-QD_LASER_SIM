function [ Nc,Nv,ni,eps1,P,Eg,taun,taup,mun,mup,Xi,C,Theta_n,Theta_p ] = StructureProfile( N,X )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
[ l1,l2,l3,het,b ] = structure_parameters();
[ c ] = constants();
% Pe = Piezo(N,X);
ni = zeros(N+1,1);
Nc = zeros(N+1,1);
Nv = zeros(N+1,1);
eps = zeros(N+1,1);
P = zeros(N+1,1);
Pe = zeros(N+1,1);
Eg = zeros(N+1,1);
taun = zeros(N+1,1);
taup = zeros(N+1,1);
mun = zeros(N+1,1);
mup = zeros(N+1,1);
Xi = zeros(N+1,1);
C = zeros(N+1,1);
Theta_n = zeros(N+1,1);
Theta_p = zeros(N+1,1);
for i=1:N+1
    if(X(i)<=b(1))
        l = l1;          
    elseif(X(i)<=b(1)+b(2))
        l = l2;          
    elseif(X(i)<=b(1)+b(2)+b(3))
        l = l1;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4))
        l = l2;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5))
        l = l1;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6))
        l = l2;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7))
        l = l1;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8))
        l = l2;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8)+b(9))
        l = l1;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8)+b(9)+b(10))
        l = l2;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8)+b(9)+b(10)+b(11))
        l = l1;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8)+b(9)+b(10)+b(11)+b(12))
        l = l3;            
    elseif(X(i)<=b(1)+b(2)+b(3)+b(4)+b(5)+b(6)+b(7)+b(8)+b(9)+b(10)+b(11)+b(12)+b(13))
        l = l1;            
    end
    Nc(i) = l.Nc;
    Nv(i) = l.Nv;
    ni(i) = l.ni;
    eps(i) = l.eps;
    Pe(i) = 2*(l.a-l1.a)/l.a*(l.e31-l.e33*l.C13/l.C33);
    P(i) = l.P0 - Pe(i);
    Eg(i) = l.Eg;
    taun(i) = l.tau_n;
    taup(i) = l.tau_p;
    mun(i) = l.mun;
    mup(i) = l.mup;
    Xi(i) = l.Xi;
    C(i) = 2e18; 
    Theta_n(i) = (l.Xi-l1.Xi)+c.Vt*log(l.Nc/l1.Nc);
    Theta_p(i) = (-(l.Xi-l1.Xi)-(l.Eg-l1.Eg))+c.Vt*log(l.Nv/l1.Nv);
end
Theta_n = Theta_n/c.Vt;
Theta_p = Theta_p/c.Vt;
% Finite Volumes    
for i=2:N+1
    eps1(i) = (eps(i-1)+eps(i))/2;            
end    
end


